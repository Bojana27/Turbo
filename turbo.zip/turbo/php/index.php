<!DOCTYPE html>
<html lang="hr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/stil.css">
    <title>TurboCraft Garage</title>
</head>

<body>
    <!-- Pozadinski video -->
    <div class="video-container">
        <video class="background-video" autoplay muted loop>
            <source src="../images/video.mp4.mp4" type="video/mp4">
            Vaš preglednik ne podržava oznaku videa.
        </video>
    </div>

    <!-- Forma za dodavanje vozila -->
    <div class="add-vehicle-form">
        <br><br><br>
        <h2>Dodaj novo vozilo</h2>
        <form action="" method="POST">
            <div class="form-group">
                <label for="model">Model:</label>
                <input type="text" name="model" id="model" class="form-control" placeholder="Unesite model vozila" required>
            </div>
            <div class="form-group">
                <label for="year">Godina proizvodnje:</label>
                <input type="number" name="year" id="year" class="form-control" placeholder="Unesite godinu" required>
            </div>
            <div class="form-group">
                <label for="price">Cijena:</label>
                <input type="number" name="price" id="price" class="form-control" placeholder="Unesite cijenu" required>
            </div>
            <div class="form-group">
                <label for="description">Opis:</label>
                <textarea name="description" id="description" class="form-control" rows="3" placeholder="Unesite opis"></textarea>
            </div>
            <div class="form-group">
                <label for="mileage">Kilometraža:</label>
                <input type="number" name="mileage" id="mileage" class="form-control" placeholder="Unesite kilometražu" required>
            </div>
            <div class="form-group">
                <label for="fuel_type">Vrsta goriva:</label>
                <select name="fuel_type" id="fuel_type" class="form-control" required>
                    <option value="petrol">Benzin</option>
                    <option value="diesel">Dizel</option>
                    <option value="electric">Električno</option>
                    <option value="hybrid">Hibrid</option>
                </select>
            </div>
            <div class="form-group">
                <label for="transmission">Mjenjač:</label>
                <select name="transmission" id="transmission" class="form-control" required>
                    <option value="manual">Ručno</option>
                    <option value="automatic">Automatski</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Dodaj vozilo</button>
        </form>
    </div>

    <!-- Navigacija -->
    <header class="sticky-header">
        <div class="logo">
            <a href="../html/index.html">
                <img src="../images/41df0fa6-d2a6-4a1b-b76f-bd9ab40f2ebb.webp" alt="Logo">
            </a>
        </div>
        <nav>
            <ul class="nav navbar-nav">
                <li><a href="../php/index.php">Prodaja</a></li>
                <li><a href="../html/ONama.html">O trgovini</a></li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">Kupi vozilo <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li><a href="../html/Ponuda.html">Ponuda</a></li>
                        <li class="dropdown-submenu">
                            <a href="#">Pretraži po proizvođaču</a>
                            <ul class="submenu dropdown-menu">
                                <li><a href="../php/Audi.php">AUDI</a></li>
                                <li><a href="../php/BMW.php">BMW</a></li>
                                <li><a href="../php/Mercedes.php">MERCEDES</a></li>
                                <li><a href="../php/Porsche.php">PORSCHE</a></li>
                            </ul>
                        </li>
                    </ul>
                </li>
                <li><a href="kontakt.html">Kontaktiraj nas!</a></li>
            </ul>
        </nav>
    </header>

    <!-- Pretraživanje po proizvođaču -->
    <div class="search-by-manufacturer">
        <p class="manufacturer-link">Traži po proizvođaču</p>
    </div>

    <!-- Logotipi proizvođača -->
    <div class="manufacturer-logos black-bar">
        <a href="../php/Porsche.php"><img src="../images/porsche-logo.jpg" alt="Porsche"></a>
        <a href="../php/Audi.php"><img src="../images/audi-logo.jpg" alt="Audi"></a>
        <a href="../php/BMW.php"><img src="../images/bmw-logo.png" alt="BMW"></a>
        <a href="../php/Mercedes.php"><img src="../images/mercedes-logo.png" alt="Mercedes"></a>
    </div>

    <?php
    // Podaci za povezivanje
    $host = "ucka.veleri.hr";
    $username = "bkovacevic";
    $password = "11";
    $dbname = "Automobili_tc";

    // Povezivanje s bazom
    $conn = new mysqli($host, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Povezivanje s bazom nije uspjelo: " . $conn->connect_error);
    }

    // Obrada forme
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $model = $_POST['model'];
        $year = $_POST['year'];
        $price = $_POST['price'];
        $description = $_POST['description'];
        $mileage = $_POST['mileage'];
        $fuel_type = $_POST['fuel_type'];
        $transmission = $_POST['transmission'];

        $sql = "INSERT INTO Automobili_tc (model, year, price, description, mileage, fuel_type, transmission)
                VALUES ('$model', $year, $price, '$description', $mileage, '$fuel_type', '$transmission')";

        if ($conn->query($sql) === TRUE) {
            echo "<p>Vozilo uspješno dodano!</p>";
        } else {
            echo "<p>Greška: " . $conn->error . "</p>";
        }
    }

    $conn->close();
    ?>

    <!-- Skripte -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <!-- CSS za video i formu -->
    <style>
        /* Pozadinski video */
        .video-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            overflow: hidden;
        }

        .background-video {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        /* Forma za dodavanje vozila */
        .add-vehicle-form {
            position: absolute;
            top: 50%; /* Postavlja formu vertikalno u sredinu */
            left: 50%; /* Postavlja formu horizontalno u sredinu */
            transform: translate(-50%, -50%); /* Poravnanje forme u točno središte */
            margin: 0;
            max-width: 600px;
            padding: 20px;
            background: rgba(255, 255, 255, 0.8); /* Prozirna pozadina */
            border: 1px solid #ddd;
            border-radius: 5px;
            z-index: 1;
        }

        .add-vehicle-form h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        /* Skrivanje videa na manjim ekranima */
        @media (max-width: 768px) {
            .background-video {
                display: none;
            }
        }

        .dropdown-submenu:hover .submenu {
            display: block;
            left: 100%;
            top: 0;
        }

        .black-bar {
            background-color: black;
            padding: 20px 0;
        }

        .manufacturer-logos {
            display: flex;
            justify-content: space-around;
            align-items: center;
            margin-top: 0;
            max-height: 120px;
            max-width: 100%;
        }

        .manufacturer-logos img {
            max-height: 120px;
            max-width: 100%;
        }

        .search-by-manufacturer {
            background-color: rgb(68, 253, 154);
            padding: 10px;
            text-align: center;
        }

        .manufacturer-link {
            color: rgb(255, 7, 7);
            text-decoration: none;
            font-weight: bold;
        }
    </style>
</body>

</html>
