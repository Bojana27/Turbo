<?php
// Povezivanje s bazom
$host = 'ucka.veleri.hr';
$db = 'bkovacevic';
$user = 'bkovacevic';
$pass = '11';

try {
    $conn = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Greška s povezivanjem: " . $e->getMessage());
}

// Dodavanje novog zapisa
if (isset($_POST['add'])) {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];

    $sql = "INSERT INTO cars (name, description, price) VALUES (:name, :description, :price)";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['name' => $name, 'description' => $description, 'price' => $price]);
    header("Location: index.php");
}

// Brisanje zapisa
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];

    $sql = "DELETE FROM cars WHERE id = :id";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['id' => $id]);
    header("Location: index.php");
}

// Uređivanje zapisa
if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];

    $sql = "UPDATE cars SET name = :name, description = :description, price = :price WHERE id = :id";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['name' => $name, 'description' => $description, 'price' => $price, 'id' => $id]);
    header("Location: index.php");
}

// Dohvaćanje svih podataka
$sql = "SELECT * FROM cars";
$stmt = $conn->query($sql);
$cars = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD Operacije</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center">CRUD Operacije - Automobili</h1>
        <hr>

        <!-- Forma za dodavanje novog automobila -->
        <div class="card mb-4">
            <div class="card-body">
                <h5 class="card-title">Dodaj novi automobil</h5>
                <form method="POST" action="">
                    <div class="mb-3">
                        <label for="name" class="form-label">Ime</label>
                        <input type="text" class="form-control" id="name" name="name" required>
                    </div>
                    <div class="mb-3">
                        <label for="description" class="form-label">Opis</label>
                        <textarea class="form-control" id="description" name="description" rows="3" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="price" class="form-label">Cijena (EUR)</label>
                        <input type="number" class="form-control" id="price" name="price" required>
                    </div>
                    <button type="submit" name="add" class="btn btn-primary">Dodaj</button>
                </form>
            </div>
        </div>

        <!-- Prikaz svih automobila -->
        <table class="table table-striped table-hover">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Ime</th>
                    <th>Opis</th>
                    <th>Cijena (EUR)</th>
                    <th>Akcije</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($cars as $car): ?>
                    <tr>
                        <td><?= $car['id'] ?></td>
                        <td><?= htmlspecialchars($car['name']) ?></td>
                        <td><?= htmlspecialchars($car['description']) ?></td>
                        <td><?= number_format($car['price'], 2) ?>€</td>
                        <td>
                            <!-- Uredi -->
                            <button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#editModal<?= $car['id'] ?>">Uredi</button>

                            <!-- Obriši -->
                            <a href="?delete=<?= $car['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Jeste li sigurni da želite obrisati?')">Obriši</a>
                        </td>
                    </tr>

                    <!-- Modal za uređivanje -->
                    <div class="modal fade" id="editModal<?= $car['id'] ?>" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="editModalLabel">Uredi automobil</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <form method="POST" action="">
                                        <input type="hidden" name="id" value="<?= $car['id'] ?>">
                                        <div class="mb-3">
                                            <label for="name" class="form-label">Ime</label>
                                            <input type="text" class="form-control" name="name" value="<?= htmlspecialchars($car['name']) ?>" required>
                                        </div>
                                        <div class="mb-3">
                                            <label for="description" class="form-label">Opis</label>
                                            <textarea class="form-control" name="description" rows="3" required><?= htmlspecialchars($car['description']) ?></textarea>
                                        </div>
                                        <div class="mb-3">
                                            <label for="price" class="form-label">Cijena (EUR)</label>
                                            <input type="number" class="form-control" name="price" value="<?= $car['price'] ?>" required>
                                        </div>
                                        <button type="submit" name="update" class="btn btn-success">Spremi promjene</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
